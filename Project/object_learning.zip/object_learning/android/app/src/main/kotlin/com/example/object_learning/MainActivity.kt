package com.example.object_learning

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
