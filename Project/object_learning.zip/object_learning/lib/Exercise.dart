class Exercise{
  String name;
  String imageLocation;
  int reps;

  Exercise({required this.name,required this.imageLocation,required this.reps});
}