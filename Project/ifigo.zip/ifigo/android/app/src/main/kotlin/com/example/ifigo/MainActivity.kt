package com.example.ifigo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
