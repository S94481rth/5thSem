class MyRoutes{
  static String homeRoute =  "/" ;
  static String loginRoute = "/login";
  static String hard = "/hard";
  static String menu = "/menu";
  static String welcomeRoute = "/welcome";
  static String signUpRoute = "/signUp";
  static String easy = "/easy";
  static String medium = "/medium";
  static String options = "/options";
  static String customize = "/customize";

}