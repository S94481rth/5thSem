import 'package:flutter/material.dart';
import 'pages/login_page.dart';
import 'pages/sign_up.dart';
import 'pages/welcome_page.dart';
import 'utilities/routes.dart';
import 'pages/home_page.dart';
import 'pages/menu.dart';
import 'pages/exercises.dart';
import 'pages/easy.dart';
import 'pages/medium.dart';
import 'pages/options.dart';
import 'pages/customize.dart';

void main() {
  runApp(myApp());
}

class myApp extends StatelessWidget {
  const myApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
    
      themeMode: ThemeMode.light,
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),

      debugShowCheckedModeBanner: false,
      darkTheme: ThemeData(
        brightness: Brightness.dark,
      ),
      initialRoute:MyRoutes.options,
      routes: {
        MyRoutes.homeRoute:(context)=>HomePage(),
        MyRoutes.loginRoute: (context) => LoginPage(),
        MyRoutes.welcomeRoute: (context) => WelcomePage(),
        MyRoutes.signUpRoute: (context) => SignUpPage(),
        MyRoutes.menu: (context) => Menu(),
        MyRoutes.hard: (context) => Hard(),
        MyRoutes.easy: (context) => Easy(),
        MyRoutes.medium: (context) => Medium(),
        MyRoutes.options: (context) => Options(),
        MyRoutes.customize: (context) => Customize(),

        // MyRoutes.welcomeRoute: (context)=> WelcomePage(),
      },
    );
  }
}
