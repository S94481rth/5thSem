import 'package:flutter/material.dart';
import 'package:ifigo/Exercise.dart';


class Customize extends StatefulWidget {
  const Customize({Key? key}) : super(key: key);

  @override
  State<Customize> createState() => _CustomizeState();
}

class _CustomizeState extends State<Customize> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
