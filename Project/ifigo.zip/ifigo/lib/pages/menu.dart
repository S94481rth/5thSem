import 'package:flutter/material.dart';
import '../utilities/routes.dart';

class Menu extends StatefulWidget {
  const Menu({Key? key}) : super(key: key);

  @override
  State<Menu> createState() => _MenuState();
}

class _MenuState extends State<Menu> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple[200],
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Choose Difficulty',
          style:
              TextStyle(fontSize: 20.0, letterSpacing: 2, color: Colors.white),
        ),
        backgroundColor: Colors.purple[500],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            GestureDetector(
              onTap: () => {Navigator.pushNamed(context, MyRoutes.easy)},
              child: Card(
                color: Colors.green,
                margin: EdgeInsets.fromLTRB(30, 10, 10, 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(child: Image.asset('../assets/sit_up.jpeg')),
                    SizedBox(width: 50),
                    SizedBox(height: 50),
                    Expanded(
                      child: Text(
                        'Easy!',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20.0,
                            letterSpacing: 2.0),
                      ),
                    ),
                    SizedBox(width: 5),
                  ],
                ),
              ),
            ),
            SizedBox(height: 30),
            GestureDetector(
              onTap: () => {Navigator.pushNamed(context, MyRoutes.medium)},
              child: Card(
                color: Colors.yellow,
                margin: EdgeInsets.fromLTRB(30, 10, 10, 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(child: Image.asset('../assets/push_up.jpeg')),
                    SizedBox(width: 50),
                    SizedBox(height: 50),
                    Expanded(
                      child: Text(
                        'Medium!',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20.0,
                            letterSpacing: 2.0),
                      ),
                    ),
                    SizedBox(width: 5),
                  ],
                ),
              ),
            ),
            SizedBox(height: 30),
            GestureDetector(
              onTap: () => {Navigator.pushNamed(context, MyRoutes.hard)},
              child: Card(
                color: Colors.red,
                margin: EdgeInsets.fromLTRB(30, 10, 10, 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(child: Image.asset('../assets/pull_up.jpeg')),
                    SizedBox(width: 50),
                    SizedBox(height: 50),
                    Expanded(
                      child: Text(
                        'Hard!',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20.0,
                            letterSpacing: 2.0),
                      ),
                    ),
                    SizedBox(width: 5),
                  ],
                ),
              ),
            ),
            SizedBox(height: 30),
          ],
        ),

      ),
    );
  }
}
