import 'package:flutter/material.dart';
import '../utilities/routes.dart';

class Options extends StatefulWidget {
  const Options({Key? key}) : super(key: key);

  @override
  State<Options> createState() => _OptionsState();
}

class _OptionsState extends State<Options> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple[200],
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Choose Difficulty',
          style:
          TextStyle(fontSize: 20.0, letterSpacing: 2, color: Colors.white),
        ),
        backgroundColor: Colors.purple[500],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            GestureDetector(
              onTap: () => {Navigator.pushNamed(context, MyRoutes.menu)},
              child: Card(
                color: Colors.green,
                margin: EdgeInsets.fromLTRB(30, 10, 10, 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(child: Image.asset('../assets/sit_up.jpeg')),
                    SizedBox(width: 50),
                    SizedBox(height: 50),
                    Expanded(
                      child: Text(
                        'PrePlanned!',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20.0,
                            letterSpacing: 2.0),
                      ),
                    ),
                    SizedBox(width: 5),
                  ],
                ),
              ),
            ),
            SizedBox(height: 30),
            GestureDetector(
              onTap: () => {Navigator.pushNamed(context, MyRoutes.customize)},
              child: Card(
                color: Colors.yellow,
                margin: EdgeInsets.fromLTRB(30, 10, 10, 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(child: Image.asset('../assets/push_up.jpeg')),
                    SizedBox(width: 50),
                    SizedBox(height: 50),
                    Expanded(
                      child: Text(
                        'Customize!',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20.0,
                            letterSpacing: 2.0),
                      ),
                    ),
                    SizedBox(width: 5),
                  ],
                ),
              ),
            ),
            SizedBox(height: 30),
            // GestureDetector(
            //   onTap: () => {Navigator.pushNamed(context, MyRoutes.hard)},
            //   child: Card(
            //     color: Colors.red,
            //     margin: EdgeInsets.fromLTRB(30, 10, 10, 20),
            //     child: Row(
            //       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //       children: [
            //         Expanded(child: Image.asset('../assets/pull_up.jpeg')),
            //         SizedBox(width: 50),
            //         SizedBox(height: 50),
            //         Expanded(
            //           child: Text(
            //             'Hard!',
            //             style: TextStyle(
            //                 color: Colors.white,
            //                 fontSize: 20.0,
            //                 letterSpacing: 2.0),
            //           ),
            //         ),
            //         SizedBox(width: 5),
            //       ],
            //     ),
            //   ),
            // ),
            SizedBox(height: 30),
          ],
        ),

      ),
    );
  }
}
