import 'package:flutter/material.dart';
import 'package:ifigo/Exercise.dart';

class Medium extends StatefulWidget {
  const Medium({Key? key}) : super(key: key);

  @override
  State<Medium> createState() => _MediumState();
}

class _MediumState extends State<Medium> {

  List<Exercise> workouts = [
    Exercise(
        name: 'Push Ups', imageLocation: '../assets/push_up.jpeg', reps: 10),
    Exercise(
        name: 'Pull Ups', imageLocation: '../assets/pull_up.jpeg', reps: 10),
    Exercise(name: 'Sit Ups', imageLocation: '../assets/sit_up.jpeg', reps: 10),
    Exercise(name: 'Sit Ups', imageLocation: '../assets/sit_up.jpeg', reps: 10),
  ];

  Widget workoutTemplate(workout) {
    return Card(
      color: Colors.purple[500],
      margin: EdgeInsets.fromLTRB(30, 10, 10, 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Expanded(child: Image.asset(workout.imageLocation)),
          SizedBox(width: 50),
          SizedBox(height: 50),
          Expanded(
            child: Text(
              workout.name,
              style: TextStyle(color: Colors.white,fontSize: 20.0, letterSpacing: 2.0),
            ),
          ),
          SizedBox(width:5),
          Expanded(
            child: Text(
              workout.reps.toString(),
              style: TextStyle(color: Colors.white,fontSize: 15.0, letterSpacing: 2.0),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple[200],

      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Preview',
          style:
          TextStyle(fontSize: 20.0, letterSpacing: 2, color: Colors.white),
        ),
        backgroundColor: Colors.purple[500],
      ),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              Column(
                  children: workouts
                      .map((workout) => workoutTemplate(workout))
                      .toList()),
              ElevatedButton(onPressed: (){
                Navigator.pushNamed(context, '/start');
              }, child: Text("Start")),SizedBox(height:20)],
          ),
        ),
      ),

    );
  }
}
